Open Street Map (srid=4326, 2D)
- new-caledonia (french: CP1252)
- gaza (nice arabic and hebrew names: UTF-8)
- taiwan (even nicer chinese names: UTF-8)

Merano Local Council (Srid=25832, 3D, CP1252)

Foggia (Srid=23032, 2D, CP1252: very complex polygons)



