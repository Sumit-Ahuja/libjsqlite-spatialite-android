/* initializing all function pointers */
	switch (cache->pool_index)
	{
	case 0:
		cache->geos_warning = geos_warning_0;
		cache->geos_error = geos_error_0;
		break;
	case 1:
		cache->geos_warning = geos_warning_1;
		cache->geos_error = geos_error_1;
		break;
	case 2:
		cache->geos_warning = geos_warning_2;
		cache->geos_error = geos_error_2;
		break;
	case 3:
		cache->geos_warning = geos_warning_3;
		cache->geos_error = geos_error_3;
		break;
	case 4:
		cache->geos_warning = geos_warning_4;
		cache->geos_error = geos_error_4;
		break;
	case 5:
		cache->geos_warning = geos_warning_5;
		cache->geos_error = geos_error_5;
		break;
	case 6:
		cache->geos_warning = geos_warning_6;
		cache->geos_error = geos_error_6;
		break;
	case 7:
		cache->geos_warning = geos_warning_7;
		cache->geos_error = geos_error_7;
		break;
	case 8:
		cache->geos_warning = geos_warning_8;
		cache->geos_error = geos_error_8;
		break;
	case 9:
		cache->geos_warning = geos_warning_9;
		cache->geos_error = geos_error_9;
		break;
	case 10:
		cache->geos_warning = geos_warning_10;
		cache->geos_error = geos_error_10;
		break;
	case 11:
		cache->geos_warning = geos_warning_11;
		cache->geos_error = geos_error_11;
		break;
	case 12:
		cache->geos_warning = geos_warning_12;
		cache->geos_error = geos_error_12;
		break;
	case 13:
		cache->geos_warning = geos_warning_13;
		cache->geos_error = geos_error_13;
		break;
	case 14:
		cache->geos_warning = geos_warning_14;
		cache->geos_error = geos_error_14;
		break;
	case 15:
		cache->geos_warning = geos_warning_15;
		cache->geos_error = geos_error_15;
		break;
	case 16:
		cache->geos_warning = geos_warning_16;
		cache->geos_error = geos_error_16;
		break;
	case 17:
		cache->geos_warning = geos_warning_17;
		cache->geos_error = geos_error_17;
		break;
	case 18:
		cache->geos_warning = geos_warning_18;
		cache->geos_error = geos_error_18;
		break;
	case 19:
		cache->geos_warning = geos_warning_19;
		cache->geos_error = geos_error_19;
		break;
	case 20:
		cache->geos_warning = geos_warning_20;
		cache->geos_error = geos_error_20;
		break;
	case 21:
		cache->geos_warning = geos_warning_21;
		cache->geos_error = geos_error_21;
		break;
	case 22:
		cache->geos_warning = geos_warning_22;
		cache->geos_error = geos_error_22;
		break;
	case 23:
		cache->geos_warning = geos_warning_23;
		cache->geos_error = geos_error_23;
		break;
	case 24:
		cache->geos_warning = geos_warning_24;
		cache->geos_error = geos_error_24;
		break;
	case 25:
		cache->geos_warning = geos_warning_25;
		cache->geos_error = geos_error_25;
		break;
	case 26:
		cache->geos_warning = geos_warning_26;
		cache->geos_error = geos_error_26;
		break;
	case 27:
		cache->geos_warning = geos_warning_27;
		cache->geos_error = geos_error_27;
		break;
	case 28:
		cache->geos_warning = geos_warning_28;
		cache->geos_error = geos_error_28;
		break;
	case 29:
		cache->geos_warning = geos_warning_29;
		cache->geos_error = geos_error_29;
		break;
	case 30:
		cache->geos_warning = geos_warning_30;
		cache->geos_error = geos_error_30;
		break;
	case 31:
		cache->geos_warning = geos_warning_31;
		cache->geos_error = geos_error_31;
		break;
	case 32:
		cache->geos_warning = geos_warning_32;
		cache->geos_error = geos_error_32;
		break;
	case 33:
		cache->geos_warning = geos_warning_33;
		cache->geos_error = geos_error_33;
		break;
	case 34:
		cache->geos_warning = geos_warning_34;
		cache->geos_error = geos_error_34;
		break;
	case 35:
		cache->geos_warning = geos_warning_35;
		cache->geos_error = geos_error_35;
		break;
	case 36:
		cache->geos_warning = geos_warning_36;
		cache->geos_error = geos_error_36;
		break;
	case 37:
		cache->geos_warning = geos_warning_37;
		cache->geos_error = geos_error_37;
		break;
	case 38:
		cache->geos_warning = geos_warning_38;
		cache->geos_error = geos_error_38;
		break;
	case 39:
		cache->geos_warning = geos_warning_39;
		cache->geos_error = geos_error_39;
		break;
	case 40:
		cache->geos_warning = geos_warning_40;
		cache->geos_error = geos_error_40;
		break;
	case 41:
		cache->geos_warning = geos_warning_41;
		cache->geos_error = geos_error_41;
		break;
	case 42:
		cache->geos_warning = geos_warning_42;
		cache->geos_error = geos_error_42;
		break;
	case 43:
		cache->geos_warning = geos_warning_43;
		cache->geos_error = geos_error_43;
		break;
	case 44:
		cache->geos_warning = geos_warning_44;
		cache->geos_error = geos_error_44;
		break;
	case 45:
		cache->geos_warning = geos_warning_45;
		cache->geos_error = geos_error_45;
		break;
	case 46:
		cache->geos_warning = geos_warning_46;
		cache->geos_error = geos_error_46;
		break;
	case 47:
		cache->geos_warning = geos_warning_47;
		cache->geos_error = geos_error_47;
		break;
	case 48:
		cache->geos_warning = geos_warning_48;
		cache->geos_error = geos_error_48;
		break;
	case 49:
		cache->geos_warning = geos_warning_49;
		cache->geos_error = geos_error_49;
		break;
	case 50:
		cache->geos_warning = geos_warning_50;
		cache->geos_error = geos_error_50;
		break;
	case 51:
		cache->geos_warning = geos_warning_51;
		cache->geos_error = geos_error_51;
		break;
	case 52:
		cache->geos_warning = geos_warning_52;
		cache->geos_error = geos_error_52;
		break;
	case 53:
		cache->geos_warning = geos_warning_53;
		cache->geos_error = geos_error_53;
		break;
	case 54:
		cache->geos_warning = geos_warning_54;
		cache->geos_error = geos_error_54;
		break;
	case 55:
		cache->geos_warning = geos_warning_55;
		cache->geos_error = geos_error_55;
		break;
	case 56:
		cache->geos_warning = geos_warning_56;
		cache->geos_error = geos_error_56;
		break;
	case 57:
		cache->geos_warning = geos_warning_57;
		cache->geos_error = geos_error_57;
		break;
	case 58:
		cache->geos_warning = geos_warning_58;
		cache->geos_error = geos_error_58;
		break;
	case 59:
		cache->geos_warning = geos_warning_59;
		cache->geos_error = geos_error_59;
		break;
	case 60:
		cache->geos_warning = geos_warning_60;
		cache->geos_error = geos_error_60;
		break;
	case 61:
		cache->geos_warning = geos_warning_61;
		cache->geos_error = geos_error_61;
		break;
	case 62:
		cache->geos_warning = geos_warning_62;
		cache->geos_error = geos_error_62;
		break;
	case 63:
		cache->geos_warning = geos_warning_63;
		cache->geos_error = geos_error_63;
		break;
	};

